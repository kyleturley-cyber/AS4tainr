// OpenEye JVM side: runs RPG on Jariko, with file I/O routed to OpenEye core.
plugins {
    kotlin("jvm") version "2.1.0"
    application
}

group = "io.openeye"
version = "0.1.0"

val jarikoVersion: String by project

repositories {
    mavenCentral()
    // Jariko's reload dependency is sometimes published only here.
    maven("https://jitpack.io")
}

dependencies {
    implementation("io.github.smeup.jariko:rpgJavaInterpreter-core:$jarikoVersion")
    testImplementation(kotlin("test"))
}

kotlin {
    jvmToolchain(17)
}

application {
    mainClass.set("io.openeye.jvm.MainKt")
    applicationName = "openeye-jvm"
}

// Self-contained jar for the container image: java -jar openeye-jvm.jar
tasks.register<Jar>("fatJar") {
    group = "build"
    description = "Builds openeye-jvm.jar with all dependencies."
    archiveFileName.set("openeye-jvm.jar")
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
    manifest { attributes["Main-Class"] = "io.openeye.jvm.MainKt" }
    from(sourceSets.main.get().output)
    dependsOn(configurations.runtimeClasspath)
    from({ configurations.runtimeClasspath.get().filter { it.name.endsWith("jar") }.map { zipTree(it) } }) {
        exclude("META-INF/*.SF", "META-INF/*.DSA", "META-INF/*.RSA")
    }
}

tasks.test {
    useJUnitPlatform()
}
