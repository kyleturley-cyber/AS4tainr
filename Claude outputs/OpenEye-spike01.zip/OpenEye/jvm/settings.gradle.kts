rootProject.name = "openeye-jvm"
